public interface Taxable{
    int getTaxAmount();
}