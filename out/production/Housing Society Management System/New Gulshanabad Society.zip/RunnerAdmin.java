public class RunnerAdmin {
    public static void main(String[] args) {

        new mainMenuFrame();

//        new LoginPage();
//        new MemberScreen();
//        new PropertyDashboard();
//        new MemberDataInput();


    }
}
